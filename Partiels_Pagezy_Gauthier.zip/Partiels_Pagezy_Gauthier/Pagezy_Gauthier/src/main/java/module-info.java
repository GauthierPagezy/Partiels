module com.example.pagezy_gauthier {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pagezy_gauthier to javafx.fxml;
    exports com.example.pagezy_gauthier;
}