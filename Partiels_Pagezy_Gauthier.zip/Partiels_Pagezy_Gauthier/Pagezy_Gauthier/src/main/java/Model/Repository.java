package Model;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Repository {

    Statement stmt;
    ResultSet result;

    public Repository(Statement stmt) {
        this.stmt = stmt;
        this.result = null;
    }

    public ResultSet requete(Connection conn, String req) {
        try {
            this.stmt = conn.createStatement();
            this.result = this.stmt.executeQuery(req);
        } catch (Exception var4) {
        }

        return this.result;
    }
}
