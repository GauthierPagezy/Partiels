package View;

public class Vue1 {

    public Vue1() {
    }

    public void showView(ResultSet result) throws SQLException {
        String ANSI_RED = "\u001b[31m";
        String ANSI_RESET = "\u001b[0m";
        String ANSI_BLACK = "\u001b[30m";
        String ANSI_GREEN = "\u001b[32m";
        String ANSI_YELLOW = "\u001b[33m";
        String ANSI_BLUE = "\u001b[34m";
        String ANSI_PURPLE = "\u001b[35m";
        String var9 = "\u001b[36m";

        try {
            System.out.println(ANSI_BLUE + "Liste des candidats");

            while(result.next()) {
                String nom = result.getString("nom");
                String prenoms = result.getString("prenoms");
                String courriel = result.getString("courriel");
                System.out.println(nom + "\t\t\t" + prenoms + "\t\t\t" + courriel);
            }
        } catch (SQLException var13) {
            var13.getMessage();
        }

    }
}
