package View;

import java.sql.SQLException;
import bddscol.Controller.Controleur;


public class main {
        public BDDSCOL() {
        }

        public static void main(String[] args) throws SQLException {
            Controleur ctl1 = new Controleur();
            ctl1.traiterRequete();
        }
    }


