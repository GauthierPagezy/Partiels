package Controleur;
import java.Model.Connexion;
import java.Model.Repository;
import java.View.Vue1;
import java.View.Vue2;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Controleur {
    public Controleur() {
    }

    public void traiterRequete() throws SQLException {
        Statement stmt1 = null;
        Statement stmt2 = null;
        ResultSet rst1 = null;
        ResultSet rst2 = null;
        Properties props = new Properties();
        String url = "jdbc:mysql://localhost:3306/concours";
        props.setProperty("user", "root");
        props.setProperty("password", "");
        Connection conn = null;

        try {
            conn = Connexion.getConnexion(url, props);
            Vue1 vue1 = new Vue1();
            Vue2 vue2 = new Vue2();
            Repository rep1 = new Repository((Statement)stmt1);
            Repository rep2 = new Repository((Statement)stmt2);
            String req1 = "SELECT * FROM candidat";
            String req2 = "SELECT  nom, prenoms, libelle FROM candidat c INNER JOIN specialite s ON c.idSpec = s.idSpec";
            rst1 = rep1.requete(conn, req1);
            rst2 = rep2.requete(conn, req2);
            vue1.showView(rst1);
            vue2.showView(rst2);
        } catch (SQLException var14) {
            var14.getMessage();
        }

    }
}

}
